module com.example.zov {
    requires javafx.controls;
    requires javafx.fxml;
    requires camunda.bpmn.model;


    opens com.example.zov to javafx.fxml;
    exports com.example.zov;
}