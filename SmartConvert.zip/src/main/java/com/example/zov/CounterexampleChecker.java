package com.example.zov;

public class CounterexampleChecker {
}
