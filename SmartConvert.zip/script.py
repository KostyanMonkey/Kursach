import csv
import zipfile
import os
with open('') as file:
    reader = csv.DictReader(file, delimiter=',')  # указываем разделитель
    # создаем строку-шаблон для CTO-файла
    cto_template = """
    asset {2} identified by {0} {{
      o String {0};
      o String {1};
      o String {3}
    }}"""
    acl_template = """
    rule AllowAllReadAccessFor{2} {{
      description: "Allow all participants read access to {2} assets"
      participant: "org.example.{2}Participant"
      operation: READ
      resource: "org.example.{2}.{0}"
      action: ALLOW
    }}"""
    result_cto = ""
    result_acl = ""
    # обходим все строки в csv-файле
    for row in reader:
        # создаем свойства для ассета
        properties = ""
        for key in row:
            if key != 'ID' and key != 'Type' and key != 'Name':
                if row.get(key):  # если свойство существует и не пустое
                    properties += f'\n  o String {key}_{row["ID"]} // индекс для ключа {key}\n  {key} {row[key]};'
                    properties += f'\n  o String {key}_{row["Type"]}    {key}\n  {key} {row[key]};'
                    properties += f'\n  o String {key}_{row["Name"]}    {key}\n  {key} {row[key]};'
        id = row.get('ID', '')
        type = row.get('Type', '')
        name = row.get('Name', '').replace(' ', '')
        # добавляем новый ассет в cto-файл
        asset = cto_template.format(id, type, name, properties)  # название, idассета и свойства ассета
        result_cto += asset + "\n\n"
        # добавляем новое правило ACL для чтения
        acl = acl_template.format(id, type, name)
        result_acl += acl + "\n\n"
    # сохраняем результаты в файл
    with open('smartcontracts/.cto', 'w') as f:
        f.write("namespace org.example {")
        f.write(result_cto)
        f.write("}")
    with open('smartcontracts/.acl', 'w') as f:
        f.write(result_acl)
cto_file = 'smartcontracts/.cto'
acl_file = 'smartcontracts/.acl'
bna_file = 'smartcontracts/.bna'
with zipfile.ZipFile(bna_file, 'w') as myzip:
    myzip.write(cto_file, 'pharma.cto')
    myzip.write(acl_file, 'pharma.acl')
    print('bna file created successfully')
